<?php
require __DIR__ . '/../../../vendor/autoload.php';

if (!function_exists("protect")) {
  function protect()
  {
    if (!isset($_SESSION)) {
      session_start();
      if (!isset($_SESSION['user'])) {
        header('Location:../../index.php');
      }
    }
  }
}

protect();

$codigos = new Source\Controllers\ControllerPdf();
$id_passeio = $_GET['idDestino'];
// $data_passeio = 2021-04-30;




$data_passeio = $_GET['dataPasseio'];


echo "<pre>";
print_r($data_passeio);
echo "</pre>";
// exit;

$destinos = new Source\Controllers\ControllerDestinos();


?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <title>GERANDO PDF</title>

  <style>
    * {
      font-family: sans-serif;
      /* Change your font family */
    }

    .content-table {
      border-collapse: collapse;
      margin: 25px 0;
      font-size: 0.9em;
      min-width: 100%;
      max-height: 100px;
      border-radius: 5px 5px 0 0;
      overflow: hidden;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .content-table thead tr {
      background-color: #009879;
      color: #ffffff;
      text-align: left;
      font-weight: bold;
    }

    .content-table th,
    .content-table td {
      padding: 5px 12px;
    }

    .content-table tbody tr {
      border-bottom: 1px solid #dddddd;
    }

    .content-table tbody tr:nth-of-type(even) {
      background-color: #f3f3f3;
    }

    .content-table tbody tr:last-of-type {
      border-bottom: 2px solid #009879;
    }

    .content-table tbody tr.active-row {
      font-weight: bold;
      color: #009879;
    }

    /* .tamanho{
    border: 1px solid red;
    
} */
  </style>

</head>

<body>





  <div class="tamanho">

    <?php  // var_dump($destinos->read(14)) 
    ?>

    <?php $idLoja = "";

    if ($_SESSION['user'][0]['nivel_acesso_fk'] == 4) {
      $idLoja = $_SESSION['user'][0]['fk_login_loja'];
    } else {
      $idLoja = $_SESSION['user'][0]['id_login'];
    }
    ?>



    <p>Destino:<?= $destinos->read($idLoja)[0]['nome_destino'] ?> </p>

    <?php
    $codigo = "";
    $valorPassagensTodoMundo = 0;
    $valorHoteis = 0;
    $soma = 0;
    foreach ($codigos->read($id_passeio, $data_passeio) as $d) {

    ?>

      <table class="content-table">
        <thead>
          <tr>
            <th>Nome</th>
            <th>Rg</th>
            <th>Email</th>
            <th>Telefone 1</th>
            <th>Telefone 2</th>
            <th>valor da passagem R$</th>
            <th>valor de venda R$</th>
            <th>Solicitante</th>
          </tr>
        </thead>
        <tbody id="carrega_tabela_familias<?= $d['codigoDasFamilia']; ?>">
          <?php
          foreach (@$codigos->membrosFamilia($id_passeio, $d['codigoDasFamilia']) as $x) {
            @$valorPassagensTodoMundo += $x['valor_de_venda'];
          ?>
            <tr>
              <td><?= @$x['nome']; ?></td>

              <td><?= @$x['rg']; ?></td>

              <td><?= @$x['email']; ?></td>

              <td><?= @$x['telefone1']; ?></td>

              <td><?= @$x['telefone2']; ?></td>

              <td>R$<?= @$x['valor_na_epoca']; ?>,00</td>

              <td>R$<?= @$x['valor_de_venda']; ?>,00</td>


              <td><?= @$x['vendedor']; ?></td>
            </tr>
        </tbody>
      <?php } ?>

      </tbody>

      </table>

      <div id="divValores">
        <?php
        foreach (@$codigos->getValoresFinaisPdf($id_passeio, $d['codigoDasFamilia']) as $y) {
          @$valorHoteis +=  intval(@$y['valor']);

        ?>


          <?php
          $body = 'Valor das passagens: [VALORPASSAGENS] | nome do Hotel: [NOMEHOTEL] <br>
           Valor do Hotel: [VALORHOTEL] | Valor final a ser pago pela familia: [FINALFAMILIA] | valcher de entrada: [VAUCHER] ';

          $body = str_replace('[VALORPASSAGENS]', "R$" . @$y['valorPassagens'] . ",00", $body);
          $body = str_replace('[NOMEHOTEL]', @$y['nome_hotel'], $body);
          $body = str_replace('[VALORHOTEL]', "R$" . @$y['valor'] . ",00", $body);
          $body = str_replace('[FINALFAMILIA]', "R$" . @$y['valorTotalFamilia'] . ",00", $body);
          $body = str_replace('[VAUCHER]', "R$" . @$y['entrada'] . ",00", $body);
          echo $body;
          ?>




        <?php } ?>


      </div>

    <?php } ?>

  </div>

  <hr>
  <hr>


  <h3>Resumo</h3>


  <table class="content-table">
    <thead>
      <tr>
        <th>Soma de todas as passagens</th>
        <th>Soma de todas os hoteis </th>
        <th>Valor Final da Viagem</th>

      </tr>
    </thead>
    <tbody>

      <tr>
        <td>R$<?= $valorPassagensTodoMundo ?>,00</td>
        <td>R$<?= $valorHoteis ?>,00</td>
        <td>R$<?= ($valorPassagensTodoMundo + $valorHoteis) ?>,00</td>

      </tr>
    </tbody>
  </table>


  <table class="content-table">
    <thead>
      <tr>
        <th>Adultos</th>
        <th>Crianças</th>

      </tr>
    </thead>
    <tbody>

      <?php

      $idLoja = "";

      if ($_SESSION['user'][0]['nivel_acesso_fk'] == 4) {
        $idLoja = $_SESSION['user'][0]['fk_login_loja'];
      } else {
        $idLoja = $_SESSION['user'][0]['id_login'];
      }

      $adultoOuCrianca = $codigos->infos($id_passeio, $data_passeio, $idLoja);

      ?>



      <tr>
        <td><?= $adultoOuCrianca[0]['CandA'] ?></td>
        <td><?= $adultoOuCrianca[1]['CandA'] ?></td>

      </tr>


    </tbody>
  </table>



</body>

</html>