<div class="nav-lavel">Configurações Gerais</div>
<div class="nav-item has-sub">
   <a href="#"><i class="ik ik-settings"></i><span>Configurações</span></a>
   <div class="submenu-content">
      <!-- <a href="pages/Administracao/diciplinas/index.php" class="menu-item">Vendedores</a> -->
      <a href="pages/AdminMaster/Lojas.php" class="menu-item">Lojas</a>
   </div>
</div>


<!-- <div class="nav-item has-sub">
   <a href="#"><i class="ik ik-bar-chart-2"></i></i><span>Estatisticas</span></a>
   <div class="submenu-content">

      <a href="pages/Administracao/Destino.php" class="menu-item">Lojas</a>
      <a href="pages/Administracao/Veiculo.php" class="menu-item">Vendas</a>

   </div> -->


<!-- <div class="nav-item has-sub">
   <a href="#"><i class="ik ik-clipboard"></i><span>Vendedores</span></a>
   <div class="submenu-content">
      <a href="pages/Presenca/Entrada.html" class="menu-item">Comissoes</a>
      <a href="" class="menu-item">Estatisticas</a>
</div> -->
<!-- <div class="nav-item has-sub">
   <a href="#"><i class="ik ik-clipboard"></i><span>Rendimento</span></a>
   <div class="submenu-content">
      <a href="" class="menu-item">Turma</a>
      <a href="" class="menu-item">Alunos</a>
      <a href="" class="menu-item">Professores</a>
   </div>
</div> -->