<div class="nav-lavel">Configurações Gerais</div>
<div class="nav-item has-sub">
   <a href="#"><i class="ik ik-settings"></i><span>Configurações</span></a>
   <div class="submenu-content">
      <!-- <a href="pages/Administracao/diciplinas/index.php" class="menu-item">Vendedores</a> -->
      <a href="pages/Administracao/Destino.php" class="menu-item">Destinos</a>
      <a href="pages/Administracao/pontoEncontro.php" class="menu-item">Pontos de Encontro</a>
      <a href="pages/Administracao/Veiculo.php" class="menu-item">Veiculos</a>
      <a href="pages/Administracao/Passagem.php" class="menu-item">Passagens</a>
      <a href="pages/Administracao/Passeio.php" class="menu-item">Passeios</a>
      <a href="pages/Administracao/Hoteis.php" class="menu-item">Hoteis ou Pousadas</a>
      <a href="pages/Administracao/Usuarios.php" class="menu-item">Usuarios</a>
      
   </div>
</div>


<div class="nav-item has-sub">
   <a href="#"><i class="ik ik-bar-chart-2"></i></i><span>Estatisticas</span></a>
   <div class="submenu-content">
      <!-- <a href="pages/Administracao/diciplinas/index.php" class="menu-item">Vendedores</a> -->
      <a href="pages/Administracao/estatisticasVendedores.php" class="menu-item">Vendedores</a>
      <a href="pages/Administracao/estatisticas.php" class="menu-item">Vendas</a>
      <a href="pages/Administracao/graficos.php" class="menu-item">Grafico Passeio</a>
      <a href="pages/Administracao/teste3.php" class="menu-item">Grafico vendedor</a>
      <a href="pages/Administracao/graficoGeral.php" class="menu-item">Grafico Geral</a>
   </div>

</div>



<div class="nav-item has-sub">
   <a href="#"><i class="ik ik-clipboard"></i><span>Documentos</span></a>
   <div class="submenu-content">
      <!-- <a href="pages/Administracao/diciplinas/index.php" class="menu-item">Vendedores</a> -->
      <a href="pages/Administracao/GerarPdfDestino.php" class="menu-item">Pdf do Destino</a>
      <a href="pages/Administracao/GerarPdfPontoEncontro.php" class="menu-item">Pdf de endereços de busca</a>

   </div>
</div>

<div class="nav-item has-sub">
   <a href="#"><i class="ik ik-dollar-sign"></i><span>Pagamentos</span></a>
   <div class="submenu-content">
      <!-- <a href="pages/Administracao/diciplinas/index.php" class="menu-item">Vendedores</a> -->
      <a href="pages/Administracao/pagarComissao.php" class="menu-item">Pagar Comissão</a>
     
     
   </div>
</div>



<!-- <div class="nav-item has-sub">
   <a href="#"><i class="ik ik-clipboard"></i><span>Vendedores</span></a>
   <div class="submenu-content">
      <a href="pages/Presenca/Entrada.html" class="menu-item">Comissoes</a>
      <a href="" class="menu-item">Estatisticas</a>
</div> -->
<!-- <div class="nav-item has-sub">
   <a href="#"><i class="ik ik-clipboard"></i><span>Rendimento</span></a>
   <div class="submenu-content">
      <a href="" class="menu-item">Turma</a>
      <a href="" class="menu-item">Alunos</a>
      <a href="" class="menu-item">Professores</a>
   </div>
</div> -->