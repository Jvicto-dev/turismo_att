<div class="nav-lavel">Configurações Gerais</div>
<div class="nav-item has-sub">
   <a href="#"><i class="ik ik-settings"></i><span>Configurações</span></a>
   <div class="submenu-content">
      <!-- <a href="pages/Administracao/diciplinas/index.php" class="menu-item">Vendedores</a> -->
      <a href="pages/Vendedor/fazerVenda.php" class="menu-item">Fazer uma venda</a>
      <a href="pages/Vendedor/suasVendas.php" class="menu-item">Suas Vendas</a> 
      <!-- <a href="pages/Vendedor/comissão.php" class="menu-item">Comissão</a>    -->

   </div>
   
</div>


