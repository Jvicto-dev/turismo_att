<div id="dashboardVendedor">

</div>


<div id="passseio_mais_vendido_vendedor">


</div>

<!--

<div class="container-fluid">
   <div class="page-header">
      <div class="row align-items-end">
         <div class="col-lg-8">
            <div class="page-header-title">
               <i class="ik ik-star bg-blue"></i>
               <div class="d-inline">
                  <h5>Passeio mais Vendido Por você</h5>
                  <span>Passeio com o maior numero de vendas</span>
               </div>
            </div>
         </div>
      </div>
   </div>
   
   



   <div class="container-fluid">
      <div class="card-group mb-4">
         <div class="card">
            <div class="card-body">
               <div class="d-flex justify-content-between align-items-center">
                  <div class="state">
                     <h6>Beach park</h6>
                     <h3 class="text-success">456</h3>
                     <p class="card-subtitle text-muted fw-500">Total de vendas</p>
                  </div>
                  <div class="state">
                     <h6>Valor Arrecadado</h6>
                     <h3 class="text-success">R$35.524,25</h3>
                     <p class="card-subtitle text-muted fw-500">Total Arrecadado</p>
                  </div>
                  <div class="icon"><i class="ik ik-dollar-sign"></i></div>
               </div>
               <div class="progress mt-3 mb-1" style="height: 6px;">
                  <div class="progress-bar bg-success" role="progressbar" style="width: 100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                  </div>
               </div>
               <div class="text-muted f12">
               </div>
            </div>
         </div>
      </div>



   </div>




 </div>
</div> -->