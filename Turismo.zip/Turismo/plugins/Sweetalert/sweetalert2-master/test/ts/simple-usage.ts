import Swal from 'sweetalert2'

Swal.fire()
